# dias-uteis-brasil
get dias_uteis_brasil, dias_uteis_mes, hoje_eh_dia_util

########### como chamar e utilizar a classe ###################
```python
# Dia_util = Dia_util()
# res = Dia_util.feriados_nacionais(2022)    
# res = Dia_util.dias_uteis_mes(11, 2022)
# res = Dia_util.hoje_eh_dia_util(25, 12, 2022)
# print(res)
```