from dias_uteis_brasil.dias_uteis_brasil import *
dia_util = Dia_util()
imprimir = imprima()
